"""Stockfish (UCI) bridge for the Facebook Chess pipeline.

Requires the Stockfish binary path via STOCKFISH_BIN env var (or pass
explicitly). Uses python-chess's UCI transport.
"""

from __future__ import annotations

import os

import chess
import chess.engine


class StockfishBridge:
    def __init__(self, binary: str | None = None, think_time: float = 1.0):
        self.binary = binary or os.environ.get("STOCKFISH_BIN", "stockfish")
        self.think_time = think_time
        self.engine = chess.engine.SimpleEngine.popen_uci(self.binary)

    def best_move(self, fen: str) -> dict:
        """FEN -> engine best move. Returns uci/lan + legality info."""
        board = chess.Board(fen)
        if not board.is_valid():
            return {"ok": False, "error": "invalid FEN"}
        result = self.engine.play(board, chess.engine.Limit(time=self.think_time))
        return {
            "ok": True,
            "fen": fen,
            "best_move_uci": result.move.uci(),
            "best_move_san": board.san(result.move),
            "turn": "white" if board.turn == chess.WHITE else "black",
        }

    def analyse(self, fen: str, depth: int = 12) -> dict:
        board = chess.Board(fen)
        info = self.engine.analyse(board, chess.engine.Limit(depth=depth))
        score = info.get("score")
        return {
            "fen": fen,
            "depth": info.get("depth"),
            "score_cp": score.white().score() if score else None,
            "pv": [m.uci() for m in (info.get("pv") or [])[:5]],
        }

    def close(self):
        try:
            self.engine.quit()
        except Exception:
            pass

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
