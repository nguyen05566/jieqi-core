"""Board position -> FEN conversion for the Facebook Chess game.

Two strategies, tried in order:

1. DOM extractor: the game UI is DOM-based (CSS classes like
   main__play-button), so if the board squares/pieces are DOM nodes we can
   map them directly to coordinates and build a FEN.
2. Move-stream parser: game traffic goes over socket.io as JSON text
   frames. If move messages carry from/to squares, we replay them on a
   python-chess board and ask for the FEN at any point.

`analyze_board_dom(frame)` returns a structural dump (classes, counts) so
you can see what the board looks like without guessing.
"""

from __future__ import annotations

import json
from collections import Counter

import chess

# --- 1. DOM extractor -------------------------------------------------

DUMP_DOM_JS = """
() => {
  const out = [];
  const els = document.querySelectorAll('*');
  for (const el of els) {
    const cls = String(el.className || '');
    if (/square|cell|tile|piece|board|figure|notation/i.test(cls)) {
      out.push({
        tag: el.tagName,
        cls: cls.slice(0, 80),
        id: el.id || '',
        x: Math.round(el.getBoundingClientRect().x),
        y: Math.round(el.getBoundingClientRect().y),
        w: Math.round(el.getBoundingClientRect().width),
        h: Math.round(el.getBoundingClientRect().height),
        style: (el.getAttribute('style') || '').slice(0, 120),
        data: Array.from(el.attributes).filter(a => a.name.startsWith('data-'))
                 .map(a => a.name + '=' + a.value.slice(0, 30)).join('|').slice(0, 120),
      });
    }
  }
  return out;
}
"""


def analyze_board_dom(frame) -> dict:
    """Structural dump of board-related DOM nodes (no text values)."""
    try:
        els = frame.evaluate(DUMP_DOM_JS)
    except Exception as exc:
        return {"error": str(exc)[:120]}
    classes = Counter(e["cls"] for e in els)
    return {"count": len(els), "class_counts": dict(classes.most_common(20)),
            "sample": els[:10]}


# --- 2. Move-stream parser -------------------------------------------

PIECE_TO_FEN = {"p": "p", "n": "n", "b": "b", "r": "r", "q": "q", "k": "k"}


class MoveStreamBoard:
    """Replay UCI move strings onto a python-chess board."""

    def __init__(self):
        self.board = chess.Board()

    def apply_uci(self, uci: str) -> bool:
        try:
            move = chess.Move.from_uci(uci)
        except Exception:
            return False
        if move not in self.board.legal_moves:
            return False
        self.board.push(move)
        return True

    def fen(self) -> str:
        return self.board.fen()

    def reset(self):
        self.board = chess.Board()


def extract_uci_moves(payload: str) -> list[str]:
    """Find plausible UCI move strings ('e2e4', 'g1f3') in a JSON frame.

    Conservative: only 4-5 char lowercase square-pair tokens. Frame
    contents stay on the local machine; only shapes/coords are used.
    """
    import re
    try:
        obj = json.loads(payload)
    except Exception:
        obj = payload
    text = json.dumps(obj) if not isinstance(obj, str) else obj
    return re.findall(r"\b[a-h][1-8][a-h][1-8][qrbn]?\b", text)


# --- 3. FEN validation ------------------------------------------------

def validate_fen(fen: str) -> dict:
    """Check that a produced FEN is usable by an engine."""
    try:
        board = chess.Board(fen)
    except Exception as exc:
        return {"ok": False, "error": str(exc)[:120]}
    return {
        "ok": board.is_valid(),
        "turn": "white" if board.turn == chess.WHITE else "black",
        "legal_moves": board.legal_moves.count(),
    }
