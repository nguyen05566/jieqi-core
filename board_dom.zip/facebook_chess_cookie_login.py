#!/usr/bin/env python3
"""Đăng nhập Facebook bằng cookie phiên hiện có rồi mở Chess Online.

Cách dùng an toàn:
  export FB_COOKIES='datr=...; c_user=...; xs=...'
  python3 facebook_chess_cookie_login.py

Không ghi cookie vào mã nguồn hoặc commit file chứa cookie.
"""

from __future__ import annotations

import os
import sys
from http.cookies import SimpleCookie
from pathlib import Path

from playwright.sync_api import TimeoutError as PlaywrightTimeoutError
from playwright.sync_api import sync_playwright

FACEBOOK_HOME = "https://www.facebook.com/"
GAME_URL = "https://fb.gg/play/chess-vh"


def parse_cookie_header(header: str) -> list[dict]:
    """Convert a browser Cookie header into Playwright cookie objects."""
    if not header.strip():
        raise ValueError("FB_COOKIES is empty")

    parsed = SimpleCookie()
    parsed.load(header)
    if not parsed:
        raise ValueError("Could not parse FB_COOKIES")

    cookies = []
    for name, morsel in parsed.items():
        value = morsel.value
        if not name or not value:
            continue
        cookies.append(
            {
                "name": name,
                "value": value,
                "domain": ".facebook.com",
                "path": "/",
                "secure": True,
                "httpOnly": False,
                "sameSite": "Lax",
            }
        )
    if not cookies:
        raise ValueError("No usable cookies found")
    return cookies


def main() -> int:
    raw_cookies = os.environ.get("FB_COOKIES", "")
    try:
        cookies = parse_cookie_header(raw_cookies)
    except ValueError as exc:
        print(f"Cookie error: {exc}", file=sys.stderr)
        print("Example: export FB_COOKIES='datr=...; c_user=...; xs=...'", file=sys.stderr)
        return 2

    screenshot_dir = Path(os.environ.get("SCREENSHOT_DIR", "screenshots"))
    screenshot_dir.mkdir(parents=True, exist_ok=True)

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False)
        context = browser.new_context(viewport={"width": 1280, "height": 900})
        context.add_cookies(cookies)
        page = context.new_page()

        print("Opening Facebook...")
        page.goto(FACEBOOK_HOME, wait_until="domcontentloaded")
        page.wait_for_timeout(3000)

        # A logged-in Facebook page normally has a profile/menu element and no
        # email/password login form. This is only a diagnostic; no password is used.
        logged_in = (
            page.locator('input[placeholder="Email or phone"]').count() == 0
            and page.locator('input[placeholder="Search Facebook"]').count() > 0
        )
        print(f"Facebook login detected: {logged_in}")
        page.screenshot(path=str(screenshot_dir / "facebook_after_cookie.png"), full_page=False)

        print("Opening Chess Online...")
        page.goto(GAME_URL, wait_until="domcontentloaded")
        # The game is an embedded Facebook game and may need time to download assets.
        page.wait_for_timeout(15000)
        page.screenshot(path=str(screenshot_dir / "chess_online.png"), full_page=False)

        print(f"Game URL: {page.url}")
        print("The browser is left open. Inspect the game manually, then press Ctrl+C here to exit.")
        try:
            page.wait_for_timeout(10 * 60 * 1000)
        except KeyboardInterrupt:
            pass
        finally:
            context.close()
            browser.close()

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
