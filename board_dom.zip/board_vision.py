"""Canvas board -> FEN by calibrated template matching.

The game renders the chessboard on <canvas>, so we read pixels:

1. `find_canvas_bbox(frame)`  — locate the board canvas in the game iframe.
2. `slice_squares(image, bbox)` — cut the 8x8 grid into square images.
3. `calibrate(image, start_fen)` — a fresh game starts from the standard
   position, so each square image *is* a labelled piece template. This
   gives us per-square sprite templates without hardcoding art assets.
4. `image_to_fen(image, templates, orientation)` — classify each square
   by nearest template (mean abs difference) and build the FEN.

Works for any board art the game uses, as long as the camera is static.
"""

from __future__ import annotations

import io

import numpy as np
from PIL import Image

FEN_PIECES = "prnbqk"
START_FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"


# --- locating the board ------------------------------------------------

def find_canvas_bbox(frame) -> dict | None:
    """Bounding box of the largest <canvas> in the game frame."""
    try:
        boxes = frame.evaluate(
            """() => Array.from(document.querySelectorAll('canvas')).map(c => {
                 const r = c.getBoundingClientRect();
                 return {x: r.x, y: r.y, w: r.width, h: r.height};
               })"""
        )
    except Exception:
        return None
    boxes = [b for b in boxes if b["w"] > 100 and b["h"] > 100]
    if not boxes:
        return None
    return max(boxes, key=lambda b: b["w"] * b["h"])


def _crop(image: Image.Image, box: dict) -> Image.Image:
    return image.crop((int(box["x"]), int(box["y"]),
                       int(box["x"] + box["w"]), int(box["y"] + box["h"])))


# --- squares & templates ----------------------------------------------

def slice_squares(image: Image.Image, bbox: dict) -> dict[str, Image.Image]:
    """Cut the board into 64 square images keyed 'a1'..'h8'.

    Assumes white at the bottom (standard view). If the player plays
    black the board is flipped — handle via `orientation`.
    """
    board = _crop(image, bbox).resize((640, 640))
    sq = 80
    out = {}
    for rank in range(8):
        for file in range(8):
            name = chr(ord("a") + file) + str(8 - rank)
            out[name] = board.crop((file * sq, rank * sq, (file + 1) * sq, (rank + 1) * sq))
    return out


def _fingerprint(img: Image.Image) -> np.ndarray:
    """Small grayscale vector; robust to minor rendering differences."""
    arr = np.asarray(img.convert("L").resize((16, 16)), dtype=np.float32) / 255.0
    return arr.ravel()


def calibrate(squares: dict[str, Image.Image], start_fen: str = START_FEN) -> dict[str, np.ndarray]:
    """Build piece templates from a known position (default: game start)."""
    board_rows = start_fen.split()[0].split("/")
    templates: dict[str, list[np.ndarray]] = {}
    for rank in range(8):
        row, file = board_rows[rank], 0
        for ch in row:
            if ch.isdigit():
                file += int(ch)
                continue
            sq = chr(ord("a") + file) + str(8 - rank)
            templates.setdefault(ch, []).append(_fingerprint(squares[sq]))
            file += 1
    templates["_empty"] = [_fingerprint(squares[s])
                           for s in squares if s not in
                           {t for lst in templates.values() for t in []}]
    return {k: np.mean(v, axis=0) for k, v in templates.items() if v}


def classify_square(fp: np.ndarray, templates: dict[str, np.ndarray]) -> str:
    best, best_d = "_", 1e9
    for piece, tpl in templates.items():
        d = float(np.mean(np.abs(fp - tpl)))
        if d < best_d:
            best, best_d = piece, d
    return best


def image_to_fen(image: Image.Image, bbox: dict,
                 templates: dict[str, np.ndarray],
                 flipped: bool = False) -> str:
    """Screenshot -> FEN using calibrated templates.

    flipped=True when the player's side is at the bottom but black.
    """
    squares = slice_squares(image, bbox)
    grid: dict[str, str] = {}
    for name, img in squares.items():
        piece = classify_square(_fingerprint(img), templates)
        if piece != "_empty" and piece != "_":
            grid[name] = piece
    return grid_to_fen(grid)


def grid_to_fen(grid: dict[str, str]) -> str:
    rows = []
    for rank in range(8, 0, -1):
        row, empty = "", 0
        for file in "abcdefgh":
            piece = grid.get(f"{file}{rank}")
            if piece is None:
                empty += 1
            else:
                if empty:
                    row += str(empty)
                    empty = 0
                row += piece
        if empty:
            row += str(empty)
        rows.append(row)
    return "/".join(rows) + " w - - 0 1"


def png_bytes_to_image(data: bytes) -> Image.Image:
    return Image.open(io.BytesIO(data))
