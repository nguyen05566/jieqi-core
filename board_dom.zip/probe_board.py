#!/usr/bin/env python3
"""Dump the 8x8 board-cell background-image URL matrix from the game DOM."""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from playwright.sync_api import sync_playwright

from fb_game import enter_game, js_click, parse_cookie_header

OUT = Path(".openclaw/tmp")

DUMP_MATRIX_JS = """
() => {
  const rows = document.querySelectorAll('div.board-row');
  if (!rows.length) return null;
  return Array.from(rows).map(r =>
    Array.from(r.querySelectorAll('div.board-cell-content')).map(c => {
      const bg = getComputedStyle(c).backgroundImage;
      return bg.replace(/^url\\(["']?/, '').replace(/["']?\\)$/, '');
    })
  );
}
"""


def main() -> int:
    cookies = parse_cookie_header(os.environ.get("FB_COOKIES", ""))
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False, args=["--no-sandbox", "--disable-dev-shm-usage"])
        context = browser.new_context(viewport={"width": 1280, "height": 900}, locale="en-US")
        context.add_cookies(cookies)
        page, game_frame = enter_game(context)
        js_click(game_frame, "button.main__play-button")
        page.wait_for_timeout(5000)
        js_click(game_frame, "button")  # no-op safety
        # mode select -> BLITZ
        game_frame.evaluate("""() => {
          for (const el of document.querySelectorAll('button, [role=button], a, div, span')) {
            const t = (el.textContent || '').trim().toUpperCase();
            if (t.includes('BLITZ') && t.length < 40) { el.click(); return true; }
          }
          return false;
        }""")
        page.wait_for_timeout(5000)
        # dismiss FB modal if present
        for label in ("Cancel", "Save game"):
            try:
                el = page.get_by_text(label, exact=False).first
                if el.is_visible():
                    el.click()
                    break
            except Exception:
                pass
        page.wait_for_timeout(15000)
        page.screenshot(path=str(OUT / "probe_match.png"))

        matrix = game_frame.evaluate(DUMP_MATRIX_JS)
        (OUT / "board_urls.json").write_text(json.dumps(matrix, indent=1))
        print(f"[PROBE] matrix rows={len(matrix) if matrix else 0} -> {OUT}/board_urls.json", flush=True)
        if matrix:
            for row in matrix:
                print(" | ".join(u.split("/")[-1][:18] if u != "none" else "-" for u in row), flush=True)
        # leave table
        for label in ("RESIGN", "LEAVE", "QUIT", "BACK"):
            ok = game_frame.evaluate(
                """needle => { for (const el of document.querySelectorAll('button, [role=button], a, div, span')) {
                     const t = (el.textContent || '').trim().toUpperCase();
                     if (t.includes(needle) && t.length < 30) { el.click(); return true; } }
                   return false; }""", label)
            if ok:
                print(f"[PROBE] left via {label}", flush=True)
                break
        context.close()
        browser.close()
    print("[DONE]", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
