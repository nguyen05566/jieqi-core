"""Board -> FEN from the game's DOM (the board is plain DOM, not canvas).

Structure found in the live game (frame `apps-*.apps.fbsbx.com`):

    div.board > div.board-row (x8) > div.board-cell (x8)
        > div.board-cell-content  (background-image = spritesheet,
                                   background-position = piece)

We don't hardcode the art: `read_matrix(frame)` returns an 8x8 token
matrix (image@position@size), and `calibrate(matrix)` learns the
token -> piece mapping from the standard starting position of a fresh
game, discovering board orientation automatically.
"""

from __future__ import annotations

import re

import chess

START_LAYOUT_FEN_PLACEMENT = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR"

START_LAYOUT = [
    list("rnbqkbnr"),
    list("pppppppp"),
    list("........"),
    list("........"),
    list("........"),
    list("........"),
    list("PPPPPPPP"),
    list("RNBQKBNR"),
]

DUMP_MATRIX_JS = """
() => {
  const rows = document.querySelectorAll('div.board-row');
  if (!rows.length) return null;
  return Array.from(rows).map(r =>
    Array.from(r.querySelectorAll('div.board-cell-content')).map(c => {
      const cs = getComputedStyle(c);
      let tok = cs.backgroundImage + '@' + cs.backgroundPosition;
      const k = c.firstElementChild;
      if (k) {
        const ks = getComputedStyle(k);
        const img = (k.tagName === 'IMG' && k.src) ? k.src : ks.backgroundImage;
        tok += '|child:' + img + '@' + ks.backgroundPosition + '@' + String(k.className || '').slice(0, 60);
      }
      return tok;
    })
  );
}
"""


def read_matrix(frame) -> list[list[str]] | None:
    """8x8 matrix of style tokens; None if the board is not on screen."""
    try:
        matrix = frame.evaluate(DUMP_MATRIX_JS)
    except Exception:
        return None
    if not matrix or len(matrix) != 8:
        return None
    return matrix


def calibrate(matrix: list[list[str]]) -> tuple[dict[str, str], bool] | None:
    """Learn token->piece from a standard starting position.

    Two real orientations exist: white at the bottom (normal) or at the
    top (board rotated 180 degrees when we play black). We pick the one
    that reproduces the known starting FEN exactly.

    Returns (mapping, flipped) or None if inconsistent with a start.
    """
    candidates = []
    for flipped in (False, True):
        mapping: dict[str, str] = {}
        ok = True
        for r in range(8):
            for c in range(8):
                token = matrix[r][c]
                piece = START_LAYOUT[7 - r][7 - c] if flipped else START_LAYOUT[r][c]
                if token in mapping:
                    if mapping[token] != piece:
                        ok = False
                        break
                mapping[token] = piece
            if not ok:
                break
        if not ok or len(mapping) < 3:
            continue
        fen = tokens_to_fen(matrix, mapping, flipped)
        candidates.append((mapping, flipped, fen))
        if fen.split()[0] == START_LAYOUT_FEN_PLACEMENT:
            return mapping, flipped
    # fallback: first consistent candidate (position may not be the start)
    return (candidates[0][0], candidates[0][1]) if candidates else None


def tokens_to_fen(matrix: list[list[str]], mapping: dict[str, str], flipped: bool) -> str:
    grid: dict[str, str] = {}
    for r in range(8):
        for c in range(8):
            piece = mapping.get(matrix[r][c], ".")
            if piece == ".":
                continue
            file_idx = 7 - c if flipped else c
            rank_idx = r + 1 if flipped else 8 - r
            grid[chr(ord("a") + file_idx) + str(rank_idx)] = piece
    return grid_to_fen(grid)


def grid_to_fen(grid: dict[str, str]) -> str:
    rows = []
    for rank in range(8, 0, -1):
        row, empty = "", 0
        for file in "abcdefgh":
            piece = grid.get(f"{file}{rank}")
            if piece is None:
                empty += 1
            else:
                if empty:
                    row += str(empty)
                    empty = 0
                row += piece
        if empty:
            row += str(empty)
        rows.append(row)
    placement = "/".join(rows)
    castling = "KQkq" if placement == START_LAYOUT_FEN_PLACEMENT else "-"
    return f"{placement} w {castling} - 0 1"


def validate_fen(fen: str) -> dict:
    try:
        board = chess.Board(fen)
    except Exception as exc:
        return {"ok": False, "error": str(exc)[:120]}
    return {
        "ok": board.is_valid(),
        "turn": "white" if board.turn == chess.WHITE else "black",
        "legal_moves": board.legal_moves.count(),
    }


def extract_uci_moves(payload: str) -> list[str]:
    """Conservative scan for UCI move tokens in a JSON game frame."""
    try:
        import json
        obj = json.loads(payload)
        text = json.dumps(obj)
    except Exception:
        text = payload
    return re.findall(r"\b[a-h][1-8][a-h][1-8][qrbn]?\b", text)
