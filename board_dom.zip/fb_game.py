"""Enter Facebook Chess game (Vizor) using cookie-based session.

Usage:
    export FB_COOKIES='datr=...; c_user=...; xs=...'
    python3 quickplay_test.py

Everything here is observation-level: it logs in with the user's own
cookies, launches the game client, and reads the board. It does NOT
auto-play engine moves in live matches (see README).
"""

from __future__ import annotations

import json
import os
from http.cookies import SimpleCookie

from playwright.sync_api import sync_playwright

FACEBOOK_HOME = "https://www.facebook.com/"
GAME_URL = "https://www.facebook.com/gaming/play/wx-chess"

# Client-side-only: hide every promo overlay container that blocks the board.
HIDE_PROMO_JS = """
() => {
  let hidden = 0;
  document.querySelectorAll('[class*="new-chess"]').forEach(el => {
    const cs = getComputedStyle(el);
    if (cs.display !== 'none' && el.offsetWidth > 150 && el.offsetHeight > 100) {
      el.style.display = 'none';
      hidden++;
    }
  });
  return 'hidden-' + hidden;
}
"""


def js_click(frame, selector: str) -> bool:
    """Click a DOM node via JS (bypasses Playwright actionability checks).

    Used for game UI buttons that Playwright considers hidden/covered.
    """
    try:
        return bool(frame.evaluate(
            "sel => { const el = document.querySelector(sel); "
            "if (!el) return false; el.click(); return true; }", selector))
    except Exception:
        return False


def parse_cookie_header(header: str) -> list[dict]:
    """Parse a Cookie header string into Playwright cookie objects.

    Cookies are read from the FB_COOKIES environment variable only —
    never hardcode them into source files.
    """
    parsed = SimpleCookie()
    parsed.load(header)
    if not parsed:
        raise ValueError("FB_COOKIES is empty or invalid")
    return [
        {"name": n, "value": m.value, "domain": ".facebook.com", "path": "/",
         "secure": True, "httpOnly": False, "sameSite": "Lax"}
        for n, m in parsed.items() if n and m.value
    ]


def find_game_frame(page):
    """The game runs inside an fbsbx.com apps iframe."""
    for f in page.frames:
        if "apps-" in f.url and "fbsbx.com" in f.url:
            return f
    return None


def enter_game(context, warmup_ms: int = 5000, load_ms: int = 25000):
    """Warm up the Facebook session, then open the game page.

    Returns (page, game_frame). The game auto-launches for returning
    players; a promo overlay may cover the board.
    """
    page = context.new_page()
    page.goto(FACEBOOK_HOME, wait_until="domcontentloaded", timeout=60000)
    page.wait_for_timeout(warmup_ms)
    page.goto(GAME_URL, wait_until="domcontentloaded", timeout=60000)
    page.wait_for_timeout(load_ms)
    game_frame = find_game_frame(page)
    if game_frame is not None:
        try:
            game_frame.evaluate(HIDE_PROMO_JS)
        except Exception:
            pass
    return page, game_frame
