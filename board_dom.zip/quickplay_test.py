#!/usr/bin/env python3
"""Integration test: Facebook Chess quick play -> DOM board -> FEN -> Stockfish.

Stages:
  1. cookie login (FB_COOKIES env) and enter the game
  2. if a finished/continue screen is up, go BACK to the menu
  3. click PLAY -> mode select (ONLINE count is visible on this screen)
  4. click BLITZ (quick play), wait for the board (div.board-row)
  5. calibrate token->piece mapping from the standard starting position
  6. read the board again later -> FEN -> validate -> Stockfish best move

Verification only: it does NOT auto-play engine moves in the live match.
After the test it tries to leave the table via the game's own control.

Usage:
  export FB_COOKIES='...'
  export STOCKFISH_BIN=.openclaw/tmp/stockfish/stockfish-ubuntu-x86-64-avx2
  xvfb-run -a python3 chess_fb_engine/quickplay_test.py
"""

from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from playwright.sync_api import sync_playwright

import board_dom as bd
from engine_bridge import StockfishBridge
from fb_game import enter_game, js_click, parse_cookie_header

OUT = Path(".openclaw/tmp")
OUT.mkdir(parents=True, exist_ok=True)


def js_click_text(frame, needle: str) -> bool:
    try:
        return bool(frame.evaluate(
            """needle => {
                 for (const el of document.querySelectorAll('button, [role=button], a, div, span')) {
                   const t = (el.textContent || '').trim().toUpperCase();
                   if (t.includes(needle) && t.length < 40) { el.click(); return true; }
                 }
                 return false;
               }""", needle.upper()))
    except Exception:
        return False


def wait_for_board(game_frame, timeout_s: int = 30, min_unique: int = 8):
    """Wait until the board grid exists AND pieces have rendered.

    The grid paints first (2 tokens: light/dark squares); a starting
    position adds many piece tokens, so require >= min_unique tokens.
    """
    deadline = time.time() + timeout_s
    last = None
    while time.time() < deadline:
        matrix = bd.read_matrix(game_frame)
        if matrix is not None:
            last = matrix
            unique = {t for row in matrix for t in row}
            if len(unique) >= min_unique:
                time.sleep(2)  # let the render settle
                return bd.read_matrix(game_frame) or matrix
        time.sleep(2)
    return last


def main() -> int:
    try:
        cookies = parse_cookie_header(os.environ.get("FB_COOKIES", ""))
    except ValueError as exc:
        print(f"Cookie error: {exc}", file=sys.stderr)
        return 2

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False, args=["--no-sandbox", "--disable-dev-shm-usage"])
        context = browser.new_context(viewport={"width": 1280, "height": 900}, locale="en-US")
        context.add_cookies(cookies)

        print("[1] entering game ...", flush=True)
        page, game_frame = enter_game(context)
        print(f"[1] game_frame={game_frame is not None}", flush=True)

        # A finished game's 'CONTINUE / VIEW RESULTS' screen may be up.
        try:
            has_results = game_frame.evaluate(
                "() => (document.body.textContent || '').toUpperCase().includes('VIEW RESULTS')")
        except Exception:
            has_results = False
        if has_results and js_click_text(game_frame, "BACK"):
            print("[2] dismissed finished-game screen via BACK", flush=True)
            page.wait_for_timeout(4000)

        print("[3] PLAY -> mode select ...", flush=True)
        js_click(game_frame, "button.main__play-button")
        page.wait_for_timeout(6000)
        page.screenshot(path=str(OUT / "mode_select.png"))
        print(f"[3] screenshot -> {OUT}/mode_select.png (ONLINE count here)", flush=True)

        print("[4] BLITZ (quick play) ...", flush=True)
        clicked = js_click_text(game_frame, "BLITZ")
        print(f"[4] blitz clicked={clicked}", flush=True)

        page.wait_for_timeout(6000)
        for label in ("Cancel", "Save game"):  # FB 'Save to Your games' modal
            try:
                el = page.get_by_text(label, exact=False).first
                if el.is_visible():
                    el.click()
                    print(f"[4] dismissed FB modal ({label})", flush=True)
                    break
            except Exception:
                pass

        matrix = wait_for_board(game_frame, timeout_s=60)
        page.screenshot(path=str(OUT / "match_board.png"))
        print(f"[5] board matrix={'8x8' if matrix else 'NOT FOUND'} -> {OUT}/match_board.png", flush=True)

        fen1 = fen2 = None
        mapping = None
        if matrix:
            cal = bd.calibrate(matrix)
            if cal is None:
                print("[5] calibration failed (board not in starting position?)", flush=True)
                (OUT / "board_tokens.json").write_text(json.dumps(matrix, indent=1))
            else:
                mapping, flipped = cal
                fen1 = bd.tokens_to_fen(matrix, mapping, flipped)
                print(f"[5] calibrated ok (flipped={flipped}) FEN(start)={fen1}", flush=True)
                (OUT / "board_tokens.json").write_text(json.dumps(matrix, indent=1))

                print("[6] waiting 30s for board activity ...", flush=True)
                page.wait_for_timeout(30000)
                matrix2 = bd.read_matrix(game_frame)
                if matrix2:
                    fen2 = bd.tokens_to_fen(matrix2, mapping, flipped)
                print(f"[6] FEN(after wait)={fen2}", flush=True)
                page.screenshot(path=str(OUT / "match_later.png"))

        fen = fen2 or fen1
        if fen:
            check = bd.validate_fen(fen)
            print(f"[7] validate={check}", flush=True)
            if check.get("ok"):
                sf_bin = os.environ.get("STOCKFISH_BIN", "stockfish")
                with StockfishBridge(sf_bin, think_time=1.0) as sf:
                    res = sf.best_move(fen)
                print(f"[7] stockfish={res}", flush=True)
                print("[7] engine communication OK (verification only, no moves played).", flush=True)
        else:
            print("[7] no FEN produced.", flush=True)

        for label in ("RESIGN", "LEAVE", "QUIT", "SURRENDER", "BACK"):
            if js_click_text(game_frame, label):
                print(f"[8] left table via '{label}'.", flush=True)
                break

        context.close()
        browser.close()
    print("[DONE]", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
